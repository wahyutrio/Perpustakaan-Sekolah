<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host     = "sql102.infinityfree.com";
$username = "if0_39958456";
$password = "rqcZbwc15c7RZhi"; 
$database = "if0_39958456_perpustakaan";

// buat koneksi
$connect = mysqli_connect($host, $username, $password, $database);

// cek koneksi
if (!$connect) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// optional: set charset
mysqli_set_charset($connect, 'utf8mb4');

// tambahkan alias agar $conn juga bisa dipakai
$conn = $connect;
?>
