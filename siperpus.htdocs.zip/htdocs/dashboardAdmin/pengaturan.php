<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}

// Hapus admin
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM admin WHERE id_admin=$id");
    echo "<script>alert('Admin berhasil dihapus!'); window.location='pengaturan.php';</script>";
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM admin");
$jumlah = mysqli_num_rows($result);
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pengaturan Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-dark text-white">
      <h4 class="mb-0">Pengaturan Admin</h4>
    </div>
    <div class="card-body">
      <p>Total Admin: <strong><?php echo $jumlah; ?></strong></p>
      <a href="dashboard.php" class="btn btn-primary mb-3">Dashboard</a>
      <a href="tambahadmin.php" class="btn btn-success mb-3">Tambah Admin</a>
      <div class="table-responsive">
        <table class="table table-bordered table-striped">
          <thead class="table-dark">
            <tr>
              <th>ID</th>
              <th>Foto</th>
              <th>Nama</th>
              <th>Username</th>
              <th>Role</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody>
          <?php if ($jumlah > 0): ?>
              <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                  <td><?php echo $row['id_admin']; ?></td>
                  <td>
                      <?php if (!empty($row['foto'])): ?>
                          <img src="../assets/uploads/<?= htmlspecialchars($row['foto']) ?>" width="50" height="50" style="object-fit: cover;">
                      <?php else: ?>
                          <img src="../assets/adminLogo.png" width="50">
                      <?php endif; ?>
                  </td>
                  <td><?php echo $row['nama']; ?></td>
                  <td><?php echo $row['username']; ?></td>
                  <td><?php echo $row['role']; ?></td>
                  <td>
                  <a href="pengaturan.php?hapus=<?php echo $row['id_admin']; ?>" 
                    class="btn btn-danger btn-sm" 
                    onclick="return confirm('Yakin ingin menghapus admin ini?')">Hapus</a>
                  </td>
                </tr>
              <?php endwhile; ?>
          <?php else: ?>
              <tr><td colspan="6" class="text-center">Belum ada admin</td></tr>
          <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</body>
</html>