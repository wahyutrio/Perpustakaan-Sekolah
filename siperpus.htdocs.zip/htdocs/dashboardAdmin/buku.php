<?php
session_start();
include 'config.php';

// Pastikan hanya admin yang bisa akses
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// Tambah buku
if (isset($_POST['tambah'])) {
    $nomor    = $_POST['nomor_buku'] ?? '';
    $judul     = $_POST['judul'] ?? '';
    $pengarang = $_POST['pengarang'] ?? '';
    $penerbit  = $_POST['penerbit'] ?? '';
    $tahun     = (int)($_POST['tahun'] ?? 0);
    $kategori  = $_POST['kategori'] ?? '';
    $stok      = (int)($_POST['stok'] ?? 0);

    $stmt = mysqli_prepare($connect,
        "INSERT INTO buku (nomor_buku, judul, pengarang, penerbit, tahun_terbit, kategori, jumlah_stok) 
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    mysqli_stmt_bind_param($stmt, "ssssisi", $nomor, $judul, $pengarang, $penerbit, $tahun, $kategori, $stok);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: buku.php");
    exit;
}

// Update buku
if (isset($_POST['update'])) {
    $id        = (int)$_POST['id_buku'];
    $nomor    = $_POST['nomor_buku'] ?? '';
    $judul     = $_POST['judul'] ?? '';
    $pengarang = $_POST['pengarang'] ?? '';
    $penerbit  = $_POST['penerbit'] ?? '';
    $tahun     = (int)($_POST['tahun'] ?? 0);
    $kategori  = $_POST['kategori'] ?? '';
    $stok      = (int)($_POST['stok'] ?? 0);

    $stmt = mysqli_prepare($connect,
        "UPDATE buku SET nomor_buku=?, judul=?, pengarang=?, penerbit=?, tahun_terbit=?, kategori=?, jumlah_stok=? 
         WHERE id_buku=?"
    );
    mysqli_stmt_bind_param($stmt, "ssssisii", $nomor, $judul, $pengarang, $penerbit, $tahun, $kategori, $stok, $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: buku.php");
    exit;
}

// Hapus buku
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $stmt = mysqli_prepare($connect, "DELETE FROM buku WHERE id_buku = ?");
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    header("Location: buku.php");
    exit;
}

// Ambil data buku
$result = mysqli_query($connect, "SELECT * FROM buku ORDER BY id_buku DESC");
$rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Buku</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<div class="container py-4">
    <div class="card shadow">
        <div class="card-body">
            <h2 class="mb-3 text-center">📘 Data Buku</h2>

            <!-- Form Tambah -->
            <form method="POST" class="mb-3">
                <div class="row g-2">
                    <div class="col-md-6"><input type="text" name="judul" class="form-control" placeholder="Judul Buku" required></div>
                    <div class="col-md-6"><input type="text" name="nomor_buku" class="form-control" placeholder="Nomor Buku" required></div>
                    <div class="col-md-6"><input type="text" name="penerbit" class="form-control" placeholder="Penerbit" required></div>
                    <div class="col-md-6">
                        <select name="kategori" class="form-control" required>
                            <option value="">Pilih Kategori</option>
                            <option value="Fiksi">Fiksi</option>
                            <option value="Non Fiksi">Non Fiksi</option>
                            <option value="Referensi">Referensi</option>
                            <option value="Religius">Religius</option>
                        </select>
                    </div>
                    <div class="col-md-6"><input type="text" name="pengarang" class="form-control" placeholder="Pengarang" required></div>
                    <div class="col-md-6"><input type="number" name="tahun" class="form-control" placeholder="Tahun Terbit" required></div>
                    <div class="col-md-6"><input type="number" name="stok" class="form-control" placeholder="Jumlah Stok" required></div>
                </div>
                <div class="mt-3 text-center">
                    <button type="submit" name="tambah" class="btn btn-success">Tambah Buku</button>
                </div>
            </form>

            <!-- Tabel -->
            <div class="table-responsive">
                <table class="table table-striped table-hover text-center align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>ID</th><th>Nomor Buku</th><th>Judul</th><th>Pengarang</th>
                            <th>Penerbit</th><th>Tahun</th><th>Kategori</th><th>Stok</th><th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= $row['id_buku']; ?></td>
                            <td><?= $row['nomor_buku']; ?></td>
                            <td><?= $row['judul']; ?></td>
                            <td><?= $row['pengarang']; ?></td>
                            <td><?= $row['penerbit']; ?></td>
                            <td><?= $row['tahun_terbit']; ?></td>
                            <td><?= $row['kategori']; ?></td>
                            <td><?= $row['jumlah_stok']; ?></td>
                            <td>
                                <!-- Tombol Edit -->
                                <button class="btn btn-warning btn-sm" data-bs-toggle="modal" 
                                        data-bs-target="#editModal<?= $row['id_buku']; ?>">Edit</button>

                                <!-- Tombol Hapus -->
                                <a href="buku.php?hapus=<?= $row['id_buku']; ?>" 
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Yakin ingin menghapus buku ini?')">Hapus</a>
                            </td>
                        </tr>

                        <!-- Modal Edit -->
                        <div class="modal fade" id="editModal<?= $row['id_buku']; ?>" tabindex="-1">
                          <div class="modal-dialog">
                            <div class="modal-content">
                              <form method="POST">
                                <div class="modal-header bg-warning">
                                  <h5 class="modal-title">Edit Buku</h5>
                                  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="id_buku" value="<?= $row['id_buku']; ?>">
                                    <div class="mb-2"><input type="text" name="nomor_buku" class="form-control" value="<?= $row['nomor_buku']; ?>" required></div>
                                    <div class="mb-2"><input type="text" name="judul" class="form-control" value="<?= $row['judul']; ?>" required></div>
                                    <div class="mb-2"><input type="text" name="pengarang" class="form-control" value="<?= $row['pengarang']; ?>" required></div>
                                    <div class="mb-2"><input type="text" name="penerbit" class="form-control" value="<?= $row['penerbit']; ?>" required></div>
                                    <div class="mb-2"><input type="number" name="tahun" class="form-control" value="<?= $row['tahun_terbit']; ?>" required></div>
                                    <div class="mb-2"><select name="kategori" class="form-control" required>
                                        <option <?= ($row['kategori']=="Fiksi"?"selected":""); ?>>Fiksi</option>
                                        <option <?= ($row['kategori']=="Non Fiksi"?"selected":""); ?>>Non Fiksi</option>
                                        <option <?= ($row['kategori']=="Referensi"?"selected":""); ?>>Referensi</option>
                                        <option <?= ($row['kategori']=="Religius"?"selected":""); ?>>Religius</option>
                                    </select></div>
                                    <div class="mb-2"><input type="number" name="stok" class="form-control" value="<?= $row['jumlah_stok']; ?>" required></div>
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                                  <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="mt-3 text-center">
                <a href="dashboard.php" class="btn btn-secondary">⬅ Kembali</a>
            </div>
        </div>
    </div>
</div>
</body>
</html>
