<?php
session_start();
include 'config.php';

// Cek login admin
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// Ambil filter dari URL
$filter = $_GET['filter'] ?? 'semua'; // status (semua, Dipinjam, Kembali)
$mode   = $_GET['mode'] ?? 'semua';   // mode (semua, 100, 30hari)
$action = $_GET['action'] ?? '';

// ======================
// Export CSV
// ======================
if ($action == 'download') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=history_peminjaman.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID Pinjam', 'No Buku', 'Nama Siswa', 'Kelas', 'Judul Buku', 'Tgl Pinjam', 'Jatuh Tempo', 'Tgl Kembali', 'Status', 'Denda']);

    $where = [];
    if ($filter == "Dipinjam") {
        $where[] = "p.status='Dipinjam'";
    } elseif ($filter == "Kembali") {
        $where[] = "p.status='Kembali'";
    }
    if ($mode == "30hari") {
        $where[] = "p.tgl_pinjam >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
    }
    $where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
    $limit_sql = ($mode == "100") ? "LIMIT 100" : "";

    $query = mysqli_query($conn, "
        SELECT p.id_peminjaman, p.nomor_buku, p.nama_siswa, p.kelas, p.judul_buku, 
               p.tgl_pinjam, p.tgl_jatuh_tempo, g.tgl_kembali, p.status, g.denda
        FROM peminjaman p
        LEFT JOIN pengembalian g ON p.id_peminjaman=g.id_peminjaman
        $where_sql
        ORDER BY p.id_peminjaman DESC
        $limit_sql
    ");
    while ($row = mysqli_fetch_assoc($query)) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// ======================
// "Hapus Tampilan History" → kosongkan query
// ======================
if ($action == 'resetview') {
    $result = false; // Tidak ada query, tabel kosong
} else {
    // Filter kondisi untuk tampilan
    $where = [];
    if ($filter == "Dipinjam") {
        $where[] = "p.status='Dipinjam'";
    } elseif ($filter == "Kembali") {
        $where[] = "p.status='Kembali'";
    }
    if ($mode == "30hari") {
        $where[] = "p.tgl_pinjam >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)";
    }
    $where_sql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
    $limit_sql = ($mode == "100") ? "LIMIT 100" : "";

    $result = mysqli_query($conn, "
        SELECT p.id_peminjaman,p.nomor_buku,p.nama_siswa,p.kelas,p.kategori,
               p.judul_buku,p.penerbit,p.tgl_pinjam,p.tgl_jatuh_tempo,p.status,
               g.tgl_kembali,g.denda
        FROM peminjaman p
        LEFT JOIN pengembalian g ON p.id_peminjaman=g.id_peminjaman
        $where_sql
        ORDER BY p.id_peminjaman DESC
        $limit_sql
    ");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>History Peminjaman</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: linear-gradient(135deg,#007bff,#28a745); min-height:100vh; font-family: Arial, sans-serif; }
        .card { border-radius:15px; }
        .table th, .table td { vertical-align: middle; white-space: nowrap; }
        .btn-group .btn { margin: 2px; }
        #btnScrollTop {
            position: fixed; bottom: 20px; right: 20px; width: 45px; height: 45px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center; background-color: #0d6efd;
            color: #fff; border: none; box-shadow: 0 4px 10px rgba(0,0,0,.2); cursor: pointer; z-index: 1100;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="card p-4 shadow">
        <!-- Header -->
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-3">
            <h2 class="mb-2 mb-md-0">📝 History Peminjaman</h2>
            <div class="btn-group flex-wrap">
                <a href="history.php?action=download&filter=<?= $filter; ?>&mode=<?= $mode; ?>" class="btn btn-primary btn-sm">📥 Unduh CSV</a>
                <a href="history.php?action=resetview" class="btn btn-danger btn-sm" onclick="return confirm('Hanya tampilan yang dihapus, data asli tetap ada. Lanjutkan?')">🗑 Hapus Tampilan</a>
                <a href="dashboard.php" class="btn btn-success btn-sm">⬅ Dashboard</a>
            </div>
        </div>

        <!-- Filter status -->
        <div class="mb-3 d-flex flex-wrap gap-2">
            <a href="history.php?filter=semua&mode=<?= $mode; ?>" class="btn btn-outline-dark btn-sm <?= ($filter=='semua'?'active':''); ?>">Semua</a>
            <a href="history.php?filter=Dipinjam&mode=<?= $mode; ?>" class="btn btn-outline-warning btn-sm <?= ($filter=='Dipinjam'?'active':''); ?>">Dipinjam</a>
            <a href="history.php?filter=Kembali&mode=<?= $mode; ?>" class="btn btn-outline-success btn-sm <?= ($filter=='Kembali'?'active':''); ?>">Kembali</a>
        </div>

        <!-- Filter Mode -->
        <div class="mb-3">
            <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle btn-sm" type="button" data-bs-toggle="dropdown">
                    🔎 Filter Data
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item <?= ($mode=='semua'?'active':''); ?>" href="history.php?filter=<?= $filter; ?>&mode=semua">Semua Data</a></li>
                    <li><a class="dropdown-item <?= ($mode=='100'?'active':''); ?>" href="history.php?filter=<?= $filter; ?>&mode=100">100 Data Terakhir</a></li>
                    <li><a class="dropdown-item <?= ($mode=='30hari'?'active':''); ?>" href="history.php?filter=<?= $filter; ?>&mode=30hari">30 Hari Terakhir</a></li>
                </ul>
            </div>
        </div>

        <!-- Tabel -->
        <div class="table-responsive">
            <table class="table table-striped table-bordered text-center align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nomor Buku</th>
                        <th>Nama</th>
                        <th>Kelas</th>
                        <th>Kategori</th>
                        <th>Judul</th>
                        <th>Penerbit</th>
                        <th>Tgl Pinjam</th>
                        <th>Jatuh Tempo</th>
                        <th>Status</th>
                        <th>Tgl Kembali</th>
                        <th>Denda</th>
                    </tr>
                </thead>
                <tbody>
                <?php if(!$result || mysqli_num_rows($result) == 0) { ?>
                    <tr><td colspan="12" class="text-muted">📭 Tidak ada data untuk ditampilkan.</td></tr>
                <?php } else { while($row=mysqli_fetch_assoc($result)){ ?>
                    <tr>
                        <td><?= htmlspecialchars($row['id_peminjaman']); ?></td>
                        <td><?= htmlspecialchars($row['nomor_buku']); ?></td>
                        <td class="text-start"><?= htmlspecialchars($row['nama_siswa']); ?></td>
                        <td><?= htmlspecialchars($row['kelas']); ?></td>
                        <td><?= htmlspecialchars($row['kategori']); ?></td>
                        <td class="text-start"><?= htmlspecialchars($row['judul_buku']); ?></td>
                        <td><?= htmlspecialchars($row['penerbit']); ?></td>
                        <td><?= htmlspecialchars($row['tgl_pinjam']); ?></td>
                        <td><?= htmlspecialchars($row['tgl_jatuh_tempo']); ?></td>
                        <td>
                            <?php if($row['status']=='Dipinjam'){ ?>
                                <span class="badge bg-warning text-dark">Dipinjam</span>
                            <?php } elseif($row['status']=='Kembali'){ ?>
                                <span class="badge bg-success">Kembali</span>
                            <?php } else { ?>
                                <span class="badge bg-secondary"><?= htmlspecialchars($row['status']); ?></span>
                            <?php } ?>
                        </td>
                        <td><?= htmlspecialchars($row['tgl_kembali'] ?? '-'); ?></td>
                        <td><?= ($row['denda']!==null)? "Rp ".number_format($row['denda'],0,',','.') : '-'; ?></td>
                    </tr>
                <?php } } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Scroll Top -->
<button id="btnScrollTop" title="Kembali ke atas">↑</button>
<script>
document.getElementById("btnScrollTop").addEventListener("click", () => window.scrollTo({ top: 0, behavior: 'smooth' }));
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
