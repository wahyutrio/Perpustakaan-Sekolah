<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// Sertakan file konfigurasi database dan konek
include 'config.php';
$db = $conn ?? $connect;

// --- 1. AMBIL DATA PROFIL ADMIN ---
$admin_session_data = $_SESSION['admin'];
$id_admin = is_array($admin_session_data) ? ($admin_session_data['id_admin'] ?? null) : $admin_session_data;

$admin_nama = 'Admin';
$admin_role = 'Administrator';
$foto_profil = 'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'; // Default icon

if ($id_admin) {
    $sql_user = "SELECT nama, role, foto FROM admin WHERE id_admin = ?";
    if ($stmt_user = mysqli_prepare($db, $sql_user)) {
        mysqli_stmt_bind_param($stmt_user, "i", $id_admin);
        mysqli_stmt_execute($stmt_user);
        $result_user = mysqli_stmt_get_result($stmt_user);
        if ($user = mysqli_fetch_assoc($result_user)) {
            $admin_nama = htmlspecialchars($user['nama']);
            $admin_role = htmlspecialchars($user['role']);
            if (!empty($user['foto'])) {
                $foto_profil = '../assets/uploads/' . htmlspecialchars($user['foto']);
            }
        }
        mysqli_stmt_close($stmt_user);
    }
}

// --- 2. AMBIL DATA UNTUK STATISTIK & CHART ---
date_default_timezone_set('Asia/Jakarta');
$tanggalSekarang = date('l, d F Y');
$today_for_sql = date('Y-m-d');

// Statistik Pengunjung Hari Ini
$query_pengunjung = "SELECT COUNT(id_pengunjung) AS total_pengunjung FROM pengunjung WHERE tgl_kunjung = '$today_for_sql'";
$result_pengunjung = mysqli_query($db, $query_pengunjung);
$jumlah_pengunjung_hari_ini = mysqli_fetch_assoc($result_pengunjung)['total_pengunjung'] ?? 0;

// Statistik Peminjaman Lengkap
$total_pinjam = mysqli_query($db, "SELECT COUNT(id_peminjaman) AS val FROM peminjaman")->fetch_assoc()['val'] ?? 0;
$sudah_kembali = mysqli_query($db, "SELECT COUNT(id_peminjaman) AS val FROM peminjaman WHERE status = 'Kembali'")->fetch_assoc()['val'] ?? 0;
$belum_kembali = mysqli_query($db, "SELECT COUNT(id_peminjaman) AS val FROM peminjaman WHERE status = 'Dipinjam'")->fetch_assoc()['val'] ?? 0;
$terlambat = mysqli_query($db, "SELECT COUNT(id_peminjaman) AS val FROM peminjaman WHERE status = 'Dipinjam' AND tgl_jatuh_tempo < '$today_for_sql'")->fetch_assoc()['val'] ?? 0;

?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard Admin | SiPerpus</title>
  <link rel="icon" href="../assets/logoUrl.png" type="image/png">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif; background: #f4f6f9; overflow-x: hidden;
    }
    .sidebar {
      height: 100vh; width: 240px; position: fixed; top: 0; left: 0;
      background: linear-gradient(180deg, #283593, #1976d2); color: #fff;
      padding-top: 20px; transition: transform 0.3s ease-in-out; z-index: 1050;
    }
    .sidebar .logo img { max-width: 110px; height: auto; border-radius: 10px; }
    .sidebar h4 { margin-top: 10px; font-weight: bold; color: #ddf2fa; }
    .sidebar a {
      display: block; padding: 12px 20px; color: #fff; text-decoration: none;
      border-radius: 6px; margin: 4px 8px; transition: all 0.2s;
    }
    .sidebar a:hover { background: rgba(255, 255, 255, 0.15); }
    .overlay {
      position: fixed; top: 0; left: 0; width: 100%; height: 100%;
      background: rgba(0,0,0,0.4); display: none; z-index: 1040;
    }
    .overlay.show { display: block; }
    .content { margin-left: 240px; padding: 20px; transition: margin-left 0.3s; }
    .topbar {
      display: flex; justify-content: space-between; align-items: center;
      background: #fff; padding: 12px 20px; border-radius: 12px;
      box-shadow: 0 2px 6px rgba(0,0,0,0.1); margin-bottom: 25px;
      flex-wrap: wrap; gap: 10px;
    }
    .topbar img.admin-avatar {
      width: 38px; height: 38px; border-radius: 50%; object-fit: cover; border: 2px solid #ddd;
    }
    .toggle-btn { font-size: 1.5rem; background: none; border: none; cursor: pointer; color: #283593; display: none; }
    .menu-card {
      border-radius: 15px; padding: 20px 15px; color: #fff; font-weight: 600;
      font-size: 1rem; box-shadow: 0 4px 10px rgba(0,0,0,0.2);
      transition: transform 0.2s, box-shadow 0.2s; height: 120px;
      display: flex; justify-content: center; align-items: center; flex-direction: column;
    }
    .menu-card:hover { transform: translateY(-5px); box-shadow: 0 6px 14px rgba(0,0,0,0.3); }
    .bg-buku { background: #2196f3; } .bg-siswa { background: #0dcaf0; }
    .bg-pengunjung { background: #6f42c1; } .bg-peminjaman { background: #4caf50; }
    .bg-pengembalian { background: #ff9800; } .bg-history { background: #9c27b0; }
    @media (max-width: 991px) {
      .sidebar { transform: translateX(-100%); }
      .sidebar.show { transform: translateX(0); }
      .content { margin-left: 0; }
      .toggle-btn { display: block; }
    }
  </style>
</head>
<body>
  <div class="sidebar" id="sidebar">
    <div class="logo text-center">
      <img src="../assets/logosalafiyah.png" alt="Logo Salafiyah">
      <h4>SiPerpus</h4>
    </div>
    <a href="dashboard.php">🏠 Dashboard</a>
    <a href="pengaturan.php">👥 Daftar Admin</a>
    <a href="buku.php">📘 Buku</a>
    <a href="siswa.php">🧑‍🎓 Data Siswa</a>
    <a href="pengunjung.php">📝 Pengunjung</a>
    <a href="peminjaman.php">📖 Peminjaman</a>
    <a href="pengembalian.php">🔄 Pengembalian</a>
    <a href="history.php">💰 Denda</a>
    <hr>
    <a href="pengaturan.php">⚙ Pengaturan</a>
    <a href="logout.php" class="text-danger">🚪 Logout</a>
  </div>

  <div class="overlay" id="overlay"></div>

  <div class="content" id="content">
    <div class="topbar">
      <button class="toggle-btn d-lg-none" id="toggleSidebar">☰</button>
      <div>
        <h1 class="fw-bold" style="color:#1e293b;">Dashboard Admin</h1>
        <p class="text-muted mb-0"><?php echo $tanggalSekarang; ?></p>
      </div>
      <div class="dropdown">
        <a href="#" class="d-flex align-items-center text-dark text-decoration-none dropdown-toggle"
           id="dropdownAdmin" data-bs-toggle="dropdown" aria-expanded="false">
          <img src="<?php echo $foto_profil; ?>" alt="Admin" class="me-2 admin-avatar">
          <strong><?php echo $admin_nama; ?></strong>
        </a>
        <ul class="dropdown-menu dropdown-menu-end shadow" aria-labelledby="dropdownAdmin">
          <li class="dropdown-header">
            <strong><?php echo $admin_nama; ?></strong><br>
            <small><?php echo $admin_role; ?></small>
          </li>
          <li><a class="dropdown-item" href="profil.php"><i class="bi bi-person-circle me-2"></i> Profil</a></li>
          <li><a class="dropdown-item" href="pengaturan.php"><i class="bi bi-gear me-2"></i> Pengaturan</a></li>
          <li><a class="dropdown-item" href="tambahadmin.php"><i class="bi bi-person-plus-fill me-2"></i> Tambah Admin</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i> Keluar</a></li>
        </ul>
      </div>
    </div>

    <div class="row g-3 text-center mb-4">
        <div class="col-lg-2 col-md-4 col-6"><a href="buku.php" class="text-decoration-none"><div class="menu-card bg-buku">📘 <br> Buku</div></a></div>
        <div class="col-lg-2 col-md-4 col-6"><a href="siswa.php" class="text-decoration-none"><div class="menu-card bg-siswa">🧑‍🎓 <br> Siswa</div></a></div>
        <div class="col-lg-2 col-md-4 col-6"><a href="pengunjung.php" class="text-decoration-none"><div class="menu-card bg-pengunjung">📝 <br> Pengunjung</div></a></div>
        <div class="col-lg-2 col-md-4 col-6"><a href="peminjaman.php" class="text-decoration-none"><div class="menu-card bg-peminjaman">📖 <br> Pinjam</div></a></div>
        <div class="col-lg-2 col-md-4 col-6"><a href="pengembalian.php" class="text-decoration-none"><div class="menu-card bg-pengembalian">🔄 <br> Kembali</div></a></div>
        <div class="col-lg-2 col-md-4 col-6"><a href="history.php" class="text-decoration-none"><div class="menu-card bg-history">💰 <br> History</div></a></div>
    </div>

    <div class="row">
        <div class="col-lg-5 mb-4">
            <div class="card shadow h-100">
                <div class="card-header bg-primary text-white py-3">
                    <h6 class="m-0 fw-bold"><i class="bi bi-people-fill me-2"></i>Statistik Pengunjung</h6>
                </div>
                <div class="card-body text-center d-flex flex-column justify-content-center align-items-center">
                    <div style="width: 100%; max-width: 250px; position: relative;">
                        <canvas id="pengunjungChart"></canvas>
                        <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
                            <h2 class="fw-bolder"><?php echo $jumlah_pengunjung_hari_ini; ?></h2>
                            <p class="text-muted mb-0">Orang</p>
                        </div>
                    </div>
                    <h5 class="mt-3">Total Pengunjung Hari Ini</h5>
                </div>
            </div>
        </div>
        <div class="col-lg-7 mb-4">
            <div class="card shadow h-100">
                <div class="card-header bg-success text-white py-3">
                    <h6 class="m-0 fw-bold"><i class="bi bi-bar-chart-line-fill me-2"></i>Statistik Peminjaman Buku</h6>
                </div>
                <div class="card-body">
                    <div style="position: relative; height:250px">
                        <canvas id="peminjamanChart"></canvas>
                    </div>
                    <hr>
                    <div class="row text-center">
                        <div class="col-6 col-md-3 mb-2">
                            <h6 class="text-muted small">TOTAL PINJAM</h6>
                            <h4 class="fw-bold"><?php echo $total_pinjam; ?></h4>
                        </div>
                        <div class="col-6 col-md-3 mb-2">
                            <h6 class="text-muted small">KEMBALI</h6>
                            <h4 class="fw-bold text-success"><?php echo $sudah_kembali; ?></h4>
                        </div>
                        <div class="col-6 col-md-3 mb-2">
                            <h6 class="text-muted small">AKTIF</h6>
                            <h4 class="fw-bold text-warning"><?php echo $belum_kembali; ?></h4>
                        </div>
                        <div class="col-6 col-md-3 mb-2">
                            <h6 class="text-muted small">TERLAMBAT</h6>
                            <h4 class="fw-bold text-danger"><?php echo $terlambat; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script>
    // Sidebar Toggle
    const toggleBtn = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    toggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('show');
      overlay.classList.toggle('show');
    });
    overlay.addEventListener('click', () => {
      sidebar.classList.remove('show');
      overlay.classList.remove('show');
    });

    // Chart 1: Pengunjung (Doughnut)
    const ctxPengunjung = document.getElementById('pengunjungChart');
    new Chart(ctxPengunjung, {
        type: 'doughnut',
        data: {
            datasets: [{
                data: [<?php echo $jumlah_pengunjung_hari_ini; ?>, 0.001], // 0.001 to ensure the circle is drawn
                backgroundColor: ['#4e73df', '#eaecf4'],
                hoverBackgroundColor: ['#2e59d9', '#eaecf4'],
                borderColor: '#ffffff',
                borderWidth: 3
            }]
        },
        options: {
            maintainAspectRatio: true,
            responsive: true,
            cutout: '80%',
            plugins: {
                legend: { display: false },
                tooltip: { enabled: false }
            }
        }
    });

    // Chart 2: Peminjaman (Bar)
    const ctxPeminjaman = document.getElementById('peminjamanChart');
    new Chart(ctxPeminjaman, {
        type: 'bar',
        data: {
            labels: ['Total', 'Kembali', 'Aktif', 'Terlambat'],
            datasets: [{
                label: 'Jumlah Buku',
                data: [
                    <?php echo $total_pinjam; ?>,
                    <?php echo $sudah_kembali; ?>,
                    <?php echo $belum_kembali; ?>,
                    <?php echo $terlambat; ?>
                ],
                backgroundColor: [
                    'rgba(108, 117, 125, 0.7)',
                    'rgba(25, 135, 84, 0.7)',
                    'rgba(255, 193, 7, 0.7)',
                    'rgba(220, 53, 69, 0.7)'
                ],
                borderColor: ['#6c757d', '#198754', '#ffc107', '#dc3545'],
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            maintainAspectRatio: false,
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        precision: 0
                    }
                }
            },
            plugins: {
                legend: { display: false }
            }
        }
    });
  </script>
  <footer class="text-center py-3 mt-4 bg-light border-top">
    <p class="mb-0 text-muted" style="font-size: 0.9rem;">&copy; 2025 SiPerpus | All Rights Reserved</p>
  </footer>
</body>
</html>