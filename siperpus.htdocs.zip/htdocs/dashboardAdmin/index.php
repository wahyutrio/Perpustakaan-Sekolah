<?php
session_start();
include 'config.php';

if (isset($_POST['login'])) {
    $username = mysqli_real_escape_string($connect, $_POST['username']);
    $password = mysqli_real_escape_string($connect, $_POST['password']);

    $query  = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($connect, $query);

    if (mysqli_num_rows($result) > 0) {
        $_SESSION['admin'] = mysqli_fetch_assoc($result);
        header("Location: dashboard.php");
        exit;
    } else {
        echo "<script>alert('Username atau Password salah!');</script>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Admin Perpustakaan</title>
    <link rel="icon" href="../assets/logoUrl.png" type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- penting untuk responsif -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body {
            background: linear-gradient(135deg,#007bff,#28a745); 
            min-height:100vh; 
            display:flex; 
            justify-content:center; 
            align-items:center;
            padding: 15px; /* biar tidak mepet di layar kecil */
        }
        .card {
            border-radius:15px; 
            box-shadow:0 4px 8px rgba(0,0,0,0.2);
            padding: 20px;
            width: 100%;
            max-width: 400px; /* agar tidak terlalu lebar di laptop */
        }
        .logo {
            display: block;
            margin: 0 auto 15px auto;
            max-width: 150px; 
            height: auto;
        }

        /* === Responsif untuk HP kecil (max 576px) === */
        @media (max-width: 576px) {
            .card {
                padding: 15px;
                max-width: 100%;
            }
            .logo {
                max-width: 120px;
            }
            h3 {
                font-size: 1.2rem;
            }
            input, button {
                font-size: 0.9rem;
            }
        }

        /* === Responsif untuk tablet (577px - 992px) === */
        @media (min-width: 577px) and (max-width: 992px) {
            .card {
                max-width: 350px;
            }
            .logo {
                max-width: 140px;
            }
        }

        /* === Laptop/Desktop besar (lebih dari 992px) === */
        @media (min-width: 993px) {
            .card {
                max-width: 400px;
            }
        }
    </style>
</head>
<body>
<div class="card">
    <!-- Logo SiPerpus -->
    <img src="../assets/logoFooter.png" alt="Logo SiPerpus" class="logo">  

    <h3 class="text-center mb-3">Login Admin</h3>
    <form method="POST">
        <input type="text" name="username" class="form-control mb-2" placeholder="Username" required>
        <input type="password" name="password" class="form-control mb-2" placeholder="Password" required>
        <button class="btn btn-primary w-100" name="login">Login</button>
            <footer class="text-center py-3 mt-4 bg-light border-top">
            <p class="mb-0 text-muted" style="font-size: 0.9rem;">
            &copy; 2025 SiPerpus | All Rights Reserved
            </p>
            </footer>
    </form>
</div>

</body>
</html>
