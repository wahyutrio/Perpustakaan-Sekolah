<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}

// Ambil data admin berdasarkan ID
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $result = mysqli_query($connect, "SELECT * FROM admin WHERE id=$id");
    $admin = mysqli_fetch_assoc($result);
}

// Update data admin
if (isset($_POST['update'])) {
    $id     = intval($_POST['id']);
    $nama   = mysqli_real_escape_string($connect, $_POST['nama']);
    $user   = mysqli_real_escape_string($connect, $_POST['username']);
    $pass   = mysqli_real_escape_string($connect, $_POST['password']);

    // Jika password diisi → update semua
    if (!empty($pass)) {
        $query = "UPDATE admin SET nama='$nama', username='$user', password='$pass' WHERE id=$id";
    } else {
        $query = "UPDATE admin SET nama='$nama', username='$user' WHERE id=$id";
    }

    if (mysqli_query($connect, $query)) {
        echo "<script>alert('Admin berhasil diupdate!'); window.location='pengaturan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($connect);
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Admin</title>
</head>
<body>
    <h2>Edit Admin</h2>
    <form method="post" action="">
        <input type="hidden" name="id" value="<?= $admin['id']; ?>">

        <label>Nama:</label><br>
        <input type="text" name="nama" value="<?= $admin['nama']; ?>" required><br><br>

        <label>Username:</label><br>
        <input type="text" name="username" value="<?= $admin['username']; ?>" required><br><br>

        <label>Password (kosongkan jika tidak diganti):</label><br>
        <input type="password" name="password"><br><br>

        <button type="submit" name="update">Update</button>
        <a href="pengaturan.php">Kembali</a>
    </form>
</body>
</html>
