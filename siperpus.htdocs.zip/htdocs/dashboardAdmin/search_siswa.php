<?php
include 'config.php';

if (isset($_POST['query'])) {
    $query = mysqli_real_escape_string($conn, $_POST['query']);
    $result = mysqli_query($conn, "SELECT * FROM siswa WHERE nama LIKE '%$query%' LIMIT 10");

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<a href="pengunjung.php?tambah=' . $row['id_siswa'] . '">';
            echo htmlspecialchars($row['nama']) . ' (' . htmlspecialchars($row['kelas']) . ')';
            echo '</a>';
        }
    } else {
        echo '<div class="p-2 text-muted">Siswa tidak ditemukan. <a href="siswa.php">Tambah baru?</a></div>';
    }
}
?>