<?php
session_start();

if (file_exists(__DIR__ . '/config.php')) {
    include __DIR__ . '/config.php';
} else {
    die("config.php tidak ditemukan!");
}

if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}

$admin_id = $_SESSION['admin']['id_admin'];

// Ambil data admin
$stmt = $conn->prepare("SELECT * FROM admin WHERE id_admin = ?");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

// Proses update
if (isset($_POST['update'])) {
    $nama     = $_POST['nama'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $foto     = $admin['foto']; // Gunakan foto lama sebagai default

    // Proses upload foto baru jika ada file yang dipilih
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0 && !empty($_FILES['foto']['name'])) {
        $target_dir = "../assets/uploads/";
         if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $foto_baru = basename($_FILES["foto"]["name"]);
        $target_file = $target_dir . $foto_baru;
        if (move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file)) {
            $foto = $foto_baru;
        }
    }

    if (!empty($password)) {
        $sql = "UPDATE admin SET nama=?, username=?, password=?, foto=? WHERE id_admin=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $nama, $username, $password, $foto, $admin_id);
    } else {
        $sql = "UPDATE admin SET nama=?, username=?, foto=? WHERE id_admin=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $nama, $username, $foto, $admin_id);
    }

    if ($stmt->execute()) {
        $_SESSION['admin']['nama'] = $nama;
        $_SESSION['admin']['username'] = $username;
        $_SESSION['admin']['foto'] = $foto;
        echo "<script>alert('Profil berhasil diperbarui!'); window.location='profil.php';</script>";
        exit;
    } else {
        $error = "Gagal update profil: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Edit Profil</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-body">
            <h3 class="text-center mb-4">Edit Profil</h3>
            <?php if (!empty($error)) : ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($admin['nama']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?= htmlspecialchars($admin['username']) ?>" required>
                </div>
                <div class="mb-3">
                    <label class="form-label">Password (kosongkan jika tidak diubah)</label>
                    <input type="password" name="password" class="form-control">
                </div>
                <div class="mb-3">
                    <label class="form-label">Foto Profil (Opsional)</label>
                    <input type="file" name="foto" class="form-control">
                    <?php if (!empty($admin['foto'])): ?>
                        <p class="mt-2">Foto saat ini:</p>
                        <img src="../assets/uploads/<?= htmlspecialchars($admin['foto']) ?>" width="100" class="rounded">
                    <?php endif; ?>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                <a href="profil.php" class="btn btn-secondary">Kembali</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>