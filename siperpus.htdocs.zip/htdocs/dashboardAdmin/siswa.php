<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// Tambah siswa
if (isset($_POST['tambah'])) {
    $nis   = mysqli_real_escape_string($conn, $_POST['nis']);
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);

    $cek = mysqli_query($conn, "SELECT nis FROM siswa WHERE nis = '$nis'");
    if (mysqli_num_rows($cek) == 0) {
        mysqli_query($conn, "INSERT INTO siswa (nis, nama, kelas) VALUES ('$nis', '$nama', '$kelas')");
    } else {
        echo "<script>alert('NIS sudah terdaftar!');</script>";
    }
    echo "<script>window.location.href='siswa.php';</script>";
    exit;
}

// Hapus siswa
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    mysqli_query($conn, "DELETE FROM siswa WHERE id_siswa=$id");
    header("Location: siswa.php");
    exit;
}

// Update siswa (dari form modal)
if (isset($_POST['update'])) {
    $id    = intval($_POST['id_siswa']);
    $nis   = mysqli_real_escape_string($conn, $_POST['nis']);
    $nama  = mysqli_real_escape_string($conn, $_POST['nama']);
    $kelas = mysqli_real_escape_string($conn, $_POST['kelas']);
    
    mysqli_query($conn, "UPDATE siswa SET nis='$nis', nama='$nama', kelas='$kelas' WHERE id_siswa=$id");
    header("Location: siswa.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM siswa ORDER BY nama ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Kelola Data Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: linear-gradient(135deg,#007bff,#28a745); min-height:100vh; }
        .card { border-radius:15px; }
        .table-responsive .btn { margin-right: 5px; }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="card p-4 shadow">
        <h2 class="mb-3">🧑‍🎓 Kelola Data Siswa</h2>
        
        <form method="POST" action="siswa.php" class="row g-3 mb-4">
            <div class="col-md-3">
                <input type="text" name="nis" class="form-control" placeholder="NIS" required>
            </div>
            <div class="col-md-5">
                <input type="text" name="nama" class="form-control" placeholder="Nama Siswa" required>
            </div>
            <div class="col-md-2">
                 <select name="kelas" class="form-select" required>
                    <option value="">Pilih Kelas</option>
                    <option>VII A</option><option>VII B</option><option>VII C</option><option>VII D</option>
                    <option>VIII A</option><option>VIII B</option><option>VIII C</option><option>VIII D</option>
                    <option>IX A</option><option>IX B</option><option>IX C</option><option>IX D</option>
                </select>
            </div>
            <div class="col-md-2 d-grid">
                <button type="submit" name="tambah" class="btn btn-primary">Tambah</button>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="table-dark">
                    <tr>
                        <th>NIS</th>
                        <th>Nama Siswa</th>
                        <th>Kelas</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (mysqli_num_rows($result) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['nis']); ?></td>
                        <td><?= htmlspecialchars($row['nama']); ?></td>
                        <td><?= htmlspecialchars($row['kelas']); ?></td>
                        <td>
                            <button type="button" class="btn btn-warning btn-sm btn-ubah" 
                                    data-bs-toggle="modal" 
                                    data-bs-target="#ubahModal"
                                    data-id="<?= $row['id_siswa']; ?>"
                                    data-nis="<?= htmlspecialchars($row['nis']); ?>"
                                    data-nama="<?= htmlspecialchars($row['nama']); ?>"
                                    data-kelas="<?= htmlspecialchars($row['kelas']); ?>">
                                Ubah
                            </button>
                            <a href="siswa.php?hapus=<?= $row['id_siswa']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" class="text-center">Belum ada data siswa.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <a href="dashboard.php" class="btn btn-secondary mt-3 align-self-start">⬅ Kembali ke Dashboard</a>
    </div>
</div>

<div class="modal fade" id="ubahModal" tabindex="-1" aria-labelledby="ubahModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="ubahModalLabel">✏️ Ubah Data Siswa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="siswa.php">
        <div class="modal-body">
            <input type="hidden" name="id_siswa" id="edit_id_siswa">

            <div class="mb-3">
                <label for="edit_nis" class="form-label">NIS</label>
                <input type="text" name="nis" id="edit_nis" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="edit_nama" class="form-label">Nama Siswa</label>
                <input type="text" name="nama" id="edit_nama" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="edit_kelas" class="form-label">Kelas</label>
                <select name="kelas" id="edit_kelas" class="form-select" required>
                    <option>VII A</option><option>VII B</option><option>VII C</option><option>VII D</option>
                    <option>VIII A</option><option>VIII B</option><option>VIII C</option><option>VIII D</option>
                    <option>IX A</option><option>IX B</option><option>IX C</option><option>IX D</option>
                </select>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    // Ambil referensi modal
    var ubahModal = document.getElementById('ubahModal');
    
    // Tambahkan event listener saat modal akan ditampilkan
    ubahModal.addEventListener('show.bs.modal', function (event) {
        // Tombol yang memicu modal
        var button = event.relatedTarget;

        // Ekstrak data dari atribut data-*
        var id = button.getAttribute('data-id');
        var nis = button.getAttribute('data-nis');
        var nama = button.getAttribute('data-nama');
        var kelas = button.getAttribute('data-kelas');

        // Referensi ke elemen form di dalam modal
        var modalBody = ubahModal.querySelector('.modal-body');
        var inputId = modalBody.querySelector('#edit_id_siswa');
        var inputNis = modalBody.querySelector('#edit_nis');
        var inputNama = modalBody.querySelector('#edit_nama');
        var selectKelas = modalBody.querySelector('#edit_kelas');
        
        // Isi form modal dengan data yang diekstrak
        inputId.value = id;
        inputNis.value = nis;
        inputNama.value = nama;
        selectKelas.value = kelas;
    });
});
</script>

</body>
</html>