<?php
include 'config.php';

header('Content-Type: application/json');

$response = [];

if (isset($_POST['query'])) {
    $query = mysqli_real_escape_string($conn, $_POST['query']);
    // Mengambil data siswa berdasarkan nama yang cocok
    $result = mysqli_query($conn, "SELECT nama, kelas FROM siswa WHERE nama LIKE '%$query%' LIMIT 10");

    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $response[] = $row;
        }
    }
}

// Mengembalikan data dalam format JSON
echo json_encode($response);
?>