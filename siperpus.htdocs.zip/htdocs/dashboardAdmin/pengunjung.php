<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

$today = date('Y-m-d');

// Aksi untuk Unduh atau Hapus
if (isset($_GET['action'])) {
    // Aksi Unduh CSV
    if ($_GET['action'] == 'download') {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename=pengunjung_' . $today . '.csv');
        $output = fopen('php://output', 'w');
        fputcsv($output, ['NIS', 'Nama', 'Kelas', 'Tanggal Kunjung']);

        $query = mysqli_query($conn, "SELECT s.nis, s.nama, s.kelas, p.tgl_kunjung FROM pengunjung p JOIN siswa s ON p.id_siswa = s.id_siswa WHERE p.tgl_kunjung = '$today'");
        while ($row = mysqli_fetch_assoc($query)) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    }

    // Aksi Hapus Pengunjung Hari Ini
    if ($_GET['action'] == 'delete') {
        mysqli_query($conn, "DELETE FROM pengunjung WHERE tgl_kunjung = '$today'");
        echo "<script>alert('Data pengunjung hari ini telah dihapus.'); window.location='pengunjung.php';</script>";
        exit;
    }
}

// Proses tambah pengunjung
if (isset($_GET['tambah'])) {
    $id_siswa = intval($_GET['tambah']);
    $cek = mysqli_query($conn, "SELECT * FROM pengunjung WHERE id_siswa=$id_siswa AND tgl_kunjung='$today'");
    if (mysqli_num_rows($cek) == 0) {
        mysqli_query($conn, "INSERT INTO pengunjung (id_siswa, tgl_kunjung) VALUES ($id_siswa, '$today')");
    }
    header("Location: pengunjung.php");
    exit;
}

// Ambil data pengunjung hari ini
$result = mysqli_query($conn, "
    SELECT pengunjung.id_pengunjung, siswa.nis, siswa.nama, siswa.kelas 
    FROM pengunjung 
    JOIN siswa ON pengunjung.id_siswa = siswa.id_siswa 
    WHERE pengunjung.tgl_kunjung = '$today'
    ORDER BY pengunjung.id_pengunjung DESC
");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengunjung</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: linear-gradient(135deg,#007bff,#28a745); min-height:100vh; }
        .card { border-radius:15px; }
        #searchResults a { display: block; padding: 8px 12px; text-decoration: none; color: #333; border-bottom: 1px solid #ddd; }
        #searchResults a:hover { background-color: #f2f2f2; }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="row">
        <div class="col-md-5 mb-4">
            <div class="card shadow p-4">
                <h3 class="mb-3">🔍 Cari & Tambah Pengunjung</h3>
                <input type="text" id="searchInput" class="form-control" placeholder="Ketik nama siswa...">
                <div id="searchResults" class="mt-2 border rounded" style="max-height: 300px; overflow-y: auto; background:#fff;"></div>
                 <a href="dashboard.php" class="btn btn-secondary mt-3">⬅ Kembali ke Dashboard</a>
            </div>
        </div>

        <div class="col-md-7">
            <div class="card shadow p-4">
                <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
                    <h3 class="mb-0">👥 Pengunjung Hari Ini</h3>
                    <div class="btn-group">
                        <a href="pengunjung.php?action=download" class="btn btn-primary btn-sm">Unduh CSV</a>
                        <a href="pengunjung.php?action=delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus semua data pengunjung hari ini?')">Hapus Hari Ini</a>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead class="table-dark">
                            <tr>
                                <th>NIS</th>
                                <th>Nama</th>
                                <th>Kelas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (mysqli_num_rows($result) > 0): ?>
                                <?php while($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?= htmlspecialchars($row['nis']); ?></td>
                                    <td><?= htmlspecialchars($row['nama']); ?></td>
                                    <td><?= htmlspecialchars($row['kelas']); ?></td>
                                </tr>
                                <?php endwhile; ?>
                            <?php else: ?>
                                <tr><td colspan="3" class="text-center">Belum ada pengunjung hari ini.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('searchInput').addEventListener('keyup', function() {
    let query = this.value;
    let searchResults = document.getElementById('searchResults');

    if (query.length > 1) {
        fetch('search_siswa.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', },
            body: 'query=' + query
        })
        .then(response => response.text())
        .then(data => { searchResults.innerHTML = data; });
    } else {
        searchResults.innerHTML = '';
    }
});
</script>
</body>
</html>