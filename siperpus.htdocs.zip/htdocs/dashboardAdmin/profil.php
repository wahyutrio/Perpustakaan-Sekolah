<?php
session_start();

// --- Path configuration and DB Connection ---
$config_found = false;
if (file_exists(__DIR__ . '/config.php')) {
    require_once __DIR__ . '/config.php';
    $config_found = true;
}
if (!$config_found) {
    die("File config.php tidak ditemukan.");
}

$db = $conn ?? $connect; // Use $conn or $connect from config
if (!$db) {
    die("Koneksi database tidak tersedia.");
}
// --- End of Connection ---

// --- Authentication Check ---
if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}
// --- End of Auth Check ---

// --- Fetch Admin Data ---
$admin_session_data = $_SESSION['admin'];
$id_admin = is_array($admin_session_data) ? ($admin_session_data['id_admin'] ?? null) : $admin_session_data;

if (!$id_admin) {
    die("Session admin tidak valid.");
}

$sql = "SELECT id_admin, nama, username, password, role, foto FROM admin WHERE id_admin = ?";
$stmt = mysqli_prepare($db, $sql);
if (!$stmt) {
    die("Prepare failed: " . mysqli_error($db));
}

mysqli_stmt_bind_param($stmt, "i", $id_admin);
mysqli_stmt_execute($stmt);

$user = null;
$result = mysqli_stmt_get_result($stmt);
if ($result) {
    $user = mysqli_fetch_assoc($result);
}
mysqli_stmt_close($stmt);

if (!$user) {
    echo "User tidak ditemukan.";
    // Potentially destroy session and redirect
    // session_destroy();
    // header("Location: ../index.php");
    exit;
}
// --- End of Fetching Data ---


// --- Determine Profile Picture Path ---
// If 'foto' is not empty, use it; otherwise, fall back to the default logo.
$foto_profil = !empty($user['foto']) ? '../assets/uploads/' . htmlspecialchars($user['foto']) : '../assets/adminLogo.png';
$pw_display = htmlspecialchars($user['password'] ?? '');

?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Profil Saya</title>
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    :root{
      --glass-bg: rgba(255,255,255,0.78);
      --accent-1: #00c6ff;
      --accent-2: #007bff;
      --accent-3: #00d084;
    }
    body {
      min-height: 100vh;
      display:flex;
      align-items:center;
      justify-content:center;
      margin:0;
      background: linear-gradient(135deg,var(--accent-1),var(--accent-2),#f6fffd 50%, #ffffff 100%);
      background-size:300% 300%;
      animation: bgMove 12s ease infinite;
      font-family: "Inter", "Segoe UI", Roboto, system-ui, -apple-system, sans-serif;
    }
    @keyframes bgMove {
      0% { background-position: 0% 50%; }
      50% { background-position: 100% 50%; }
      100% { background-position: 0% 50%; }
    }

    .container-card{
      width:95%;
      max-width:900px;
      padding:28px;
      border-radius:16px;
      background: var(--glass-bg);
      box-shadow: 0 10px 30px rgba(2,6,23,0.12);
      backdrop-filter: blur(10px) saturate(120%);
      border: 1px solid rgba(255,255,255,0.7);
    }

    .avatar {
      width:108px;
      height:108px;
      border-radius:16px;
      object-fit:cover;
      border:4px solid #fff;
      box-shadow: 0 6px 18px rgba(2,6,23,0.12);
    }

    h1 {
      font-size:1.8rem;
      margin-bottom:2px;
      color:#123;
    }
    .role {
      font-weight:600;
      color: #0f9d58;
      font-size:0.95rem;
    }

    .field-label { font-weight:700; color:#345; margin-bottom:6px;}
    .small-muted { color:#666; }

    .btn-pill {
      border-radius:30px;
      padding:8px 18px;
      font-weight:600;
      white-space: nowrap;
    }
    .btn-primary {
      background: linear-gradient(135deg,var(--accent-2),var(--accent-1));
      border: none;
      color:white;
    }
    .btn-logout {
      background: linear-gradient(135deg,#6c757d,#343a40);
      border:none;
      color:white;
    }

    code.pw {
      color:#d6336c;
      font-weight:600;
      font-size:0.95rem;
      word-break: break-all;
    }

    /* Responsive */
    @media (max-width:767px){
      body {
        align-items: flex-start;
        padding-top: 30px;
      }
      .d-flex.align-items-center{
        flex-direction: column;
        text-align: center;
      }
      .ms-auto {
        margin-left: 0 !important;
        margin-top: 15px;
        justify-content: center;
        flex-wrap: wrap;
      }
      .btn-pill{
        width: 100%;
        margin-bottom:8px;
      }
      .avatar { width:88px; height:88px; margin-bottom:12px; }
      h1 { font-size:1.3rem; }
    }
  </style>
</head>
<body>
  <div class="container-card">
    <div class="d-flex align-items-center">
      <img src="<?= $foto_profil; ?>" alt="Avatar" class="avatar">
      <div class="ms-md-3">
        <h1><?php echo htmlspecialchars($user['nama']); ?></h1>
        <div class="role">Role: <?php echo htmlspecialchars($user['role']); ?></div>
      </div>
      <div class="ms-auto d-flex gap-2">
        <a href="edit_profil.php" class="btn btn-pill btn-primary">Ubah Profil</a>
        <a href="dashboard.php" class="btn btn-pill btn-logout">Dashboard</a>
      </div>
    </div>

    <hr style="margin:18px 0; border-color: rgba(0,0,0,0.06)">

    <div class="row">
      <div class="col-md-6 mb-3">
        <div class="field-label">Nama</div>
        <div class="small-muted"><?php echo htmlspecialchars($user['nama']); ?></div>
      </div>
      <div class="col-md-6 mb-3">
        <div class="field-label">Username</div>
        <div class="small-muted"><?php echo htmlspecialchars($user['username']); ?></div>
      </div>
      <div class="col-12 mt-2">
        <div class="field-label">Password</div>
        <div><code class="pw"><?php echo $pw_display; ?></code></div>
      </div>
    </div>
  </div>
</body>
</html>