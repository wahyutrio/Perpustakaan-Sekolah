<?php
session_start();
include 'config.php';

if (!isset($_SESSION['admin'])) {
    header("Location: ../index.php");
    exit;
}

// Simpan admin baru
if (isset($_POST['simpan'])) {
    $nama   = mysqli_real_escape_string($conn, $_POST['nama']);
    $user   = mysqli_real_escape_string($conn, $_POST['username']);
    $pass   = mysqli_real_escape_string($conn, $_POST['password']);
    $role   = mysqli_real_escape_string($conn, $_POST['role']);
    $foto   = ""; // Default value

    // Proses upload foto hanya jika file dipilih
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0 && !empty($_FILES['foto']['name'])) {
        $target_dir = "../assets/uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $foto = basename($_FILES["foto"]["name"]);
        $target_file = $target_dir . $foto;
        // Pindahkan file yang di-upload
        move_uploaded_file($_FILES["foto"]["tmp_name"], $target_file);
    }

    $query = "INSERT INTO admin (nama, username, password, role, foto) VALUES ('$nama', '$user', '$pass', '$role', '$foto')";
    if (mysqli_query($conn, $query)) {
        echo "<script>alert('Admin berhasil ditambahkan!'); window.location='pengaturan.php';</script>";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Tambah Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
  <div class="card shadow">
    <div class="card-header bg-primary text-white">
      <h4 class="mb-0">Tambah Admin</h4>
    </div>
    <div class="card-body">
      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">Nama Lengkap</label>
          <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Role</label>
          <select name="role" class="form-select" required>
            <option value="Admin">Admin</option>
            <option value="Pegawai">Pegawai</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="formFile" class="form-label">Foto Profil (Opsional)</label>
          <input class="form-control" type="file" id="formFile" name="foto">
        </div>
        <button type="submit" name="simpan" class="btn btn-success">Simpan</button>
        <a href="dashboard.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>
  </div>
</div>
</body>
</html>