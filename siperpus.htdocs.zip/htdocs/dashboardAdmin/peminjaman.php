<?php
session_start();

/* --- Cari file config.php --- */
$foundConfig = false;
$tryPaths = [
    __DIR__ . '/config.php',
    __DIR__ . '/../config.php',
];
foreach ($tryPaths as $p) {
    if (file_exists($p)) {
        require_once $p;
        $foundConfig = true;
        break;
    }
}
if (!$foundConfig) {
    die('❌ Error: config.php tidak ditemukan.');
}
if (!isset($conn) || !$conn) {
    die('❌ Koneksi DB gagal: ' . mysqli_connect_error());
}

/* --- Cek session admin --- */
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

/* --- Tambah peminjaman --- */
if (isset($_POST['pinjam'])) {
    // Data siswa dari hidden input
    $nama       = mysqli_real_escape_string($conn, $_POST['nama']);
    $kelas      = mysqli_real_escape_string($conn, $_POST['kelas']);
    
    // Data buku dari hidden input yang diisi oleh JavaScript
    $judul      = mysqli_real_escape_string($conn, $_POST['judul']);
    $nomor_buku = mysqli_real_escape_string($conn, $_POST['nomor_buku']);
    $kategori   = mysqli_real_escape_string($conn, $_POST['kategori']);
    $penerbit   = mysqli_real_escape_string($conn, $_POST['penerbit']);
    $id_buku    = (int)$_POST['id_buku'];

    $tgl_pinjam      = date('Y-m-d');
    $tgl_jatuh_tempo = date('Y-m-d', strtotime($tgl_pinjam . ' +3 days')); 

    // Query untuk memasukkan data peminjaman
    $sql_pinjam = "INSERT INTO peminjaman 
            (nama_siswa, kelas, kategori, judul_buku, nomor_buku, penerbit, tgl_pinjam, tgl_jatuh_tempo, status)
            VALUES ('$nama','$kelas','$kategori','$judul','$nomor_buku','$penerbit','$tgl_pinjam','$tgl_jatuh_tempo','Dipinjam')";

    if (mysqli_query($conn, $sql_pinjam)) {
        // Kurangi stok buku
        mysqli_query($conn, "UPDATE buku SET jumlah_stok = jumlah_stok - 1 WHERE id_buku = $id_buku");
    } else {
        die('❌ Gagal menyimpan data: ' . mysqli_error($conn));
    }

    header("Location: peminjaman.php");
    exit;
}

/* --- Ambil data peminjaman hanya yang status = Dipinjam --- */
$result = mysqli_query($conn, "SELECT * FROM peminjaman WHERE status='Dipinjam' ORDER BY id_peminjaman DESC");
if (!$result) {
    die("❌ Query gagal: " . mysqli_error($conn));
}

/* --- Ambil data buku untuk dropdown (hanya yang stoknya > 0) --- */
$buku_result = mysqli_query($conn, "SELECT id_buku, judul, nomor_buku, kategori, penerbit FROM buku WHERE jumlah_stok > 0 ORDER BY judul ASC");
if (!$buku_result) {
    die("❌ Query ambil data buku gagal: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peminjaman Buku</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: linear-gradient(135deg,#007bff,#28a745); min-height:100vh; font-family: Arial, sans-serif; }
        .card { border-radius:15px; }
        .table th, .table td { vertical-align: middle; }
        .badge { font-weight: 600; }
        @media (max-width: 480px) {
            .table td, .table th { font-size: 12px; padding: .4rem; }
        }
        #btnScrollTop {
            position: fixed; bottom: 20px; right: 20px;
            width: 45px; height: 45px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            background-color: #0d6efd; color: #fff; border: none;
            box-shadow: 0 4px 10px rgba(0,0,0,.2); cursor: pointer; z-index: 1100;
        }
        #searchSiswaResults div:hover {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="card p-4 shadow">
        <h2 class="mb-3">📖 Peminjaman Buku</h2>
        <div class="mb-3 d-flex gap-2">
            <a href="dashboard.php" class="btn btn-success btn-sm">⬅ Kembali</a>
            <a href="history.php" class="btn btn-dark btn-sm">📜 Lihat History</a>
        </div>

        <form method="POST" class="row g-3 mb-4">
             <div class="col-12 col-md-6 position-relative">
                <label class="form-label fw-bold">1. Cari Siswa</label>
                <input type="text" id="searchSiswaInput" class="form-control" placeholder="Ketik Nama Siswa..." autocomplete="off" required>
                <div id="searchSiswaResults" class="mt-1 border rounded position-absolute bg-white w-100" style="max-height: 200px; overflow-y: auto; z-index: 1000;"></div>
            </div>

            <input type="hidden" name="nama" id="nama_siswa_hidden">
            <input type="hidden" name="kelas" id="kelas_siswa_hidden">

            <div class="col-12 col-md-6">
                <label class="form-label fw-bold">2. Pilih Buku</label>
                <select name="id_buku" id="id_buku" class="form-select" required>
                    <option value="">Pilih Judul Buku...</option>
                    <?php while($buku = mysqli_fetch_assoc($buku_result)): ?>
                        <option 
                            value="<?= $buku['id_buku']; ?>" 
                            data-judul="<?= htmlspecialchars($buku['judul']); ?>"
                            data-nomor="<?= htmlspecialchars($buku['nomor_buku']); ?>" 
                            data-kategori="<?= htmlspecialchars($buku['kategori']); ?>" 
                            data-penerbit="<?= htmlspecialchars($buku['penerbit']); ?>">
                            <?= htmlspecialchars($buku['judul']); ?> (Stok Tersedia)
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <input type="hidden" name="judul" id="judul_buku_hidden">
            <input type="hidden" name="nomor_buku" id="nomor_buku_hidden">
            <input type="hidden" name="kategori" id="kategori_buku_hidden">
            <input type="hidden" name="penerbit" id="penerbit_buku_hidden">

            <div class="col-12 d-grid mt-4">
                <button name="pinjam" type="submit" class="btn btn-success">✓ Pinjamkan Buku</button>
            </div>
        </form>

        <h4 class="mt-4">Daftar Buku Sedang Dipinjam</h4>
        <div class="table-responsive">
        <table class="table table-bordered table-striped text-center">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nama</th>
                    <th>Kelas</th>
                    <th>Judul Buku</th>
                    <th>Nomor Buku</th>
                    <th>Tgl Pinjam</th>
                    <th>Jatuh Tempo</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($result) == 0) { ?>
                <tr><td colspan="8" class="text-muted">Belum ada buku yang sedang dipinjam</td></tr>
            <?php } else { 
                $today_ts = strtotime(date('Y-m-d'));
                while ($row = mysqli_fetch_assoc($result)) {
                    $jatuh_tempo_ts = strtotime($row['tgl_jatuh_tempo']);
                    $badge_class = $jatuh_tempo_ts < $today_ts ? "bg-danger" : "bg-warning";
            ?>
                <tr>
                    <td><?= $row['id_peminjaman']; ?></td>
                    <td class="text-start"><?= htmlspecialchars($row['nama_siswa']); ?></td>
                    <td><?= htmlspecialchars($row['kelas']); ?></td>
                    <td class="text-start"><?= htmlspecialchars($row['judul_buku']); ?></td>
                    <td><?= htmlspecialchars($row['nomor_buku']); ?></td>
                    <td><?= $row['tgl_pinjam']; ?></td>
                    <td><?= $row['tgl_jatuh_tempo']; ?></td>
                    <td><span class="badge <?= $badge_class; ?>"><?= htmlspecialchars($row['status']); ?></span></td>
                </tr>
            <?php } } ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<button id="btnScrollTop" title="Kembali ke atas">↑</button>

<script>
// Fungsi untuk scroll ke atas
document.getElementById("btnScrollTop").addEventListener("click", function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Live Search untuk Siswa
const searchInput = document.getElementById('searchSiswaInput');
const searchResults = document.getElementById('searchSiswaResults');
const namaSiswaHidden = document.getElementById('nama_siswa_hidden');
const kelasSiswaHidden = document.getElementById('kelas_siswa_hidden');

searchInput.addEventListener('keyup', function() {
    let query = this.value;

    if (query.length > 1) {
        fetch('search_siswa_peminjaman.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'query=' + encodeURIComponent(query)
        })
        .then(response => response.json())
        .then(data => {
            searchResults.innerHTML = '';
            if (data.length > 0) {
                data.forEach(siswa => {
                    const div = document.createElement('div');
                    div.innerHTML = `${siswa.nama} (${siswa.kelas})`;
                    div.style.padding = '8px 12px';
                    div.style.cursor = 'pointer';
                    
                    div.addEventListener('click', () => {
                        searchInput.value = `${siswa.nama} (${siswa.kelas})`;
                        namaSiswaHidden.value = siswa.nama;
                        kelasSiswaHidden.value = siswa.kelas;
                        searchResults.innerHTML = ''; // Kosongkan hasil setelah dipilih
                    });
                    searchResults.appendChild(div);
                });
            } else {
                searchResults.innerHTML = '<div class="p-2 text-muted">Siswa tidak ditemukan.</div>';
            }
        });
    } else {
        searchResults.innerHTML = '';
    }
});

// Event listener untuk dropdown buku
const bukuDropdown = document.getElementById('id_buku');
bukuDropdown.addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    
    // Mengisi hidden input dengan data dari atribut data-*
    document.getElementById('judul_buku_hidden').value = selectedOption.getAttribute('data-judul');
    document.getElementById('nomor_buku_hidden').value = selectedOption.getAttribute('data-nomor');
    document.getElementById('kategori_buku_hidden').value = selectedOption.getAttribute('data-kategori');
    document.getElementById('penerbit_buku_hidden').value = selectedOption.getAttribute('data-penerbit');
});


// Sembunyikan hasil pencarian siswa jika klik di luar area
document.addEventListener('click', function(event) {
    if (!searchInput.contains(event.target)) {
        searchResults.innerHTML = '';
    }
});
</script>
</body>
</html>