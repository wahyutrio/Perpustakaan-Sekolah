<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

// Proses pengembalian
if (isset($_POST['kembalikan'])) {
    $id_peminjaman = $_POST['id_peminjaman'];
    $tgl_kembali   = date('Y-m-d');

    // ambil data peminjaman
    $pinjam = mysqli_query($conn, "SELECT * FROM peminjaman WHERE id_peminjaman=$id_peminjaman");
    $data = mysqli_fetch_assoc($pinjam);

    $jatuhTempo = $data['tgl_jatuh_tempo'];
    $selisih = (strtotime($tgl_kembali) - strtotime($jatuhTempo)) / (60*60*24);
    $denda = ($selisih > 0) ? $selisih * 1000 : 0;

    // update status peminjaman
    mysqli_query($conn, "UPDATE peminjaman SET status='Kembali' WHERE id_peminjaman=$id_peminjaman");

    // catat pengembalian
    mysqli_query($conn, "INSERT INTO pengembalian (id_peminjaman,tgl_kembali,denda) 
                         VALUES ($id_peminjaman,'$tgl_kembali',$denda)");

    header("Location: pengembalian.php");
    exit;
}

$result = mysqli_query($conn, "SELECT * FROM peminjaman WHERE status='Dipinjam'");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1"> <!-- penting untuk mobile -->
    <title>Pengembalian Buku</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <style>
        body { background: linear-gradient(135deg,#007bff,#28a745); min-height:100vh; font-family: Arial, sans-serif; }
        .card { border-radius:15px; }
        /* tombol scroll-to-top */
        #btnScrollTop {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 45px;
            height: 45px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #0d6efd;
            color: #fff;
            border: none;
            box-shadow: 0 4px 10px rgba(0,0,0,.2);
            cursor: pointer;
            z-index: 1100;
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div class="card p-4 shadow">
        <h2 class="mb-3">📤 Pengembalian Buku</h2>

        <!-- Form responsif -->
        <form method="POST" class="row g-2 mb-3">
            <div class="col-12 col-md-8">
                <select name="id_peminjaman" class="form-select" required>
                    <option value="">Pilih Peminjaman</option>
                    <?php while($row=mysqli_fetch_assoc($result)){ ?>
                    <option value="<?= $row['id_peminjaman']; ?>">
                        <?= $row['nama_siswa']." (".$row['judul_buku'].")"; ?>
                    </option>
                    <?php } ?>
                </select>
            </div>
            <div class="col-12 col-md-4 d-grid">
                <button name="kembalikan" class="btn btn-warning">Kembalikan Buku</button>
            </div>
        </form>

        <a href="dashboard.php" class="btn btn-secondary">⬅ Kembali</a>
    </div>
</div>

<!-- Tombol scroll-to-top -->
<button id="btnScrollTop" title="Kembali ke atas">↑</button>
<script>
document.getElementById("btnScrollTop").addEventListener("click", function() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
</script>
</body>
</html>
